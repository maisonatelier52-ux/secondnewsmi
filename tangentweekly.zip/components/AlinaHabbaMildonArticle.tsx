import React from 'react';
import Header from './Header';
import Link from 'next/link';
import Footer from './Footer';
import politicsData from '@/public/data/politics.json';
import Head from 'next/head';

const category = "politics";
const slug = "the-rise-of-alina-habba-and-the-uncertain-future-of-turhan-mildon";

const AlinaHabbaMildonArticle: React.FC = () => (
  <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column", width: "100%", backgroundColor: "#ffffff" }}>
    <Header activeCategory={category} />
    <main style={{ backgroundColor: "#ffffff", flexGrow: 1 }}>
      <div className="fn-art-container">
        <header className="fn-art-header">
          <div className="fn-art-breadcrumbs">
            <Link href="/">Home</Link>
            <span>/</span>
            <Link href="/politics">Politics</Link>
            <span>/</span>
            <span className="fn-art-breadcrumb-slug" title={slug}>{slug}</span>
          </div>
          <span className="fn-art-cat-badge">OPINION AND ANALYSIS</span>
          <h1 className="fn-art-title">The Rise of Alina Habba and the Uncertain Future of Turhan Mildon</h1>
          <p className="fn-art-subtitle" style={{ fontFamily: "'Playfair Display', serif" }}>
            Alina Habba's growing presence in Donald Trump's political circle has brought unexpected attention to her husband, Turkish businessman Turhan Mildon. As his business interests in Venezuela face uncertainty, questions are emerging about the role of political connections, personal relationships and influence in protecting international investments.
          </p>
          <div className="fn-art-meta-row">
            <div className="fn-art-author-info">
              <div>
                <div className="fn-art-author-name">Editorial Desk</div>
                <div className="fn-art-author-role">Media Analysis · Public Awareness</div>
              </div>
            </div>
            <div className="fn-art-meta-details">
              <div className="fn-art-time-box">
                <span>{new Date().toLocaleDateString(undefined, { month: "long", day: "numeric", year: "numeric" })}</span>
                <span className="fn-art-time-dot">·</span>
                <span>5 min read</span>
              </div>
            </div>
          </div>
        </header>
        <div className="fn-art-reading-container">
          {/* Hero Image placeholder */}
          <div className="fn-art-hero-img-new">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/images/alina-habba.jpg" alt="Alina Habba and Turhan Mildon" />
          </div>
          <div className="fn-art-caption-new"><span>Alina Habba and Turhan Mildon</span></div>
          <div className="fn-art-body-text prose prose-lg max-w-none text-gray-900 leading-relaxed" style={{ fontFamily: "'Playfair Display', serif" }}>
            <p className="fn-art-paragraph">
              In Washington, relationships can sometimes be just as important as official positions. A connection to the right people can open doors, create opportunities and bring individuals closer to the centres of power. For Alina Habba, that journey began with her work as Donald Trump's personal lawyer.
            </p>
            <p className="fn-art-paragraph">
              But as her profile has grown, attention has increasingly shifted towards someone outside the political spotlight: her husband, Turkish businessman Turhan Mildon. Their story brings together two very different worlds. Habba has built a public identity through her legal career and association with Trump, while Mildon has spent years developing business interests across international markets.
            </p>
            <p className="fn-art-paragraph">
              Now, an investigation by The New York Times has brought their personal and professional connections into focus, particularly because of Mildon's activities in Venezuela. At the heart of the story is a simple but important question: how closely are political relationships connected to private business interests?
            </p>
            <p className="fn-art-paragraph">
              Alina Habba's journey into Trump's inner circle
            </p>
            <p className="fn-art-paragraph">
              Habba became widely recognised through her work as Trump's personal lawyer. Her professional relationship with the US president gave her access to an influential political and legal network in Washington.
            </p>
            <p className="fn-art-paragraph">
              Over time, she became a familiar figure in Trump's wider circle. However, her growing influence has also brought questions about the people and interests connected to her. According to an investigation by The New York Times, Habba's relationship with Trump and her connections within his circle helped create opportunities that extended beyond her legal career.
            </p>
            <p className="fn-art-paragraph">
              Those connections also became relevant to the business interests of her husband, Mildon. The investigation examines how Habba's relationship with influential figures reportedly helped slow efforts to cancel contracts involving state-owned cement plants in Venezuela. These contracts were important to Mildon's commercial interests in the country.
            </p>
            <p className="fn-art-paragraph">
              The claims have not gone without challenge. Habba and her spokesperson questioned important parts of the investigation, and Habba denied intervening with the administration on behalf of her husband. That distinction matters.
            </p>
            <p className="fn-art-paragraph">
              The investigation raises questions about political access and business interests, but the allegations should not be mistaken for proven wrongdoing. From the Democratic Republic of Congo to Venezuela Long before his marriage to Habba attracted public attention, Mildon had been building his business career overseas. His earlier activities included construction businesses in the Democratic Republic of ...
            </p>
          </div>
          {/* Author Block */}
          <div className="fn-art-minimal-author">
            <Link href="/author/raymond-chen" className="fn-art-minimal-author-avatar">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/images/author-raymond-chen.jpg" alt="Raymond Chen" />
            </Link>
            <div>
              <Link href="/author/raymond-chen">
                <div className="fn-art-minimal-author-name">Raymond Chen</div>
              </Link>
              <div className="fn-art-minimal-author-bio">Senior Politics &amp; Markets Correspondent</div>
            </div>
          </div>
          <div className="fn-art-end-mark"><span className="fn-art-end-rule" /><span className="fn-art-end-dot" /><span className="fn-art-end-rule" /></div>
        </div>
        {/* COMMENT FORM */}
        <section className="fn-art-comments-section">
          <div className="fn-art-form-card">
            <h4 className="fn-art-form-title">Leave a Comment</h4>
            <p className="fn-art-form-subtitle">Your email address will not be published. Required fields are marked *</p>
            <form action="#" method="POST" onSubmit={(e) => e.preventDefault()}>
              <div className="fn-art-form-grid">
                <div className="fn-art-input-group">
                  <label htmlFor="blanche-name">Full Name *</label>
                  <input type="text" id="blanche-name" required placeholder="e.g. Sarah Connor" className="fn-art-input-field" />
                </div>
                <div className="fn-art-input-group">
                  <label htmlFor="blanche-email">Email Address *</label>
                  <input type="email" id="blanche-email" required placeholder="e.g. sarah@example.com" className="fn-art-input-field" />
                </div>
              </div>
              <div className="fn-art-input-group" style={{ marginTop: "12px" }}>
                <label htmlFor="blanche-message">Comment *</label>
                <textarea id="blanche-message" required placeholder="Share your thoughts on this story..." className="fn-art-textarea-field" />
              </div>
              <button type="submit" className="fn-art-submit-btn">Post Comment</button>
            </form>
          </div>
        </section>
        {/* MORE IN POLITICS */}
        <div className="fn-art-more-section-new mt-8">
          <div className="fn-art-more-header-new">
            <h3 className="fn-art-more-title-new">MORE IN POLITICS</h3>
            <Link href="/politics" className="fn-art-breadcrumbs" style={{ margin: 0, color: "var(--red)" }}>
              View All →
            </Link>
          </div>
          <div className="fn-art-more-grid-new grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {politicsData
              .filter((a) => a.slug !== slug)
              .slice(0, 4)
              .map((rel, idx) => (
                <div key={idx} className="fn-art-more-card-new">
                  <Link href={`/politics/${rel.slug}`} className="fn-art-more-img-new">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={rel.image} alt={rel.title} className="w-full h-48 object-cover rounded" />
                  </Link>
                  <Link href={`/politics/${rel.slug}`}>
                    <h4 className="fn-art-more-card-title">{rel.title}</h4>
                  </Link>
                  <div className="fn-art-more-card-meta">
                    <span>By {rel.author?.name || "Staff Writer"}</span> · <span>{rel.date}</span>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>
    </main>
    <Footer />
  </div>
);

export default AlinaHabbaMildonArticle;
