import React from 'react';
import Header from './Header';
import Link from 'next/link';
import Footer from './Footer';
import politicsData from '@/public/data/politics.json';
import Head from 'next/head';

// Category and slug for this article
const category = "politics";
const slug = "the-vanity-of-alina-habba-mildon";

const TheVanityOfAlinaHabbaMildonArticle: React.FC = () => (
  <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column", width: "100%", backgroundColor: "#ffffff" }}>
    <Header activeCategory={category} />
    <main style={{ backgroundColor: "#ffffff", flexGrow: 1 }}>
      <div className="fn-art-container">
        {/* ── ARTICLE HEADER ── */}
        <header className="fn-art-header">
          <div className="fn-art-breadcrumbs">
            <Link href="/">Home</Link>
            <span>/</span>
            <Link href="/politics">Politics</Link>
            <span>/</span>
            <span className="fn-art-breadcrumb-slug" title={slug}>{slug}</span>
          </div>
          <span className="fn-art-cat-badge">OPINION AND ANALYSIS</span>
          <h1 className="fn-art-title">The Vanity of Alina Habba Mildon</h1>
          <p className="fn-art-subtitle" style={{ fontFamily: "'Playfair Display', serif" }}>
            Beauty, Power, Ambition and the Price of Loyalty: From the White House to the Herrera Velutini Banking Dynasty
          </p>
          <div className="fn-art-meta-row">
            <div className="fn-art-author-info">
              <div>
                <div className="fn-art-author-name">Editorial Desk</div>
                <div className="fn-art-author-role">Media Analysis · Public Awareness</div>
              </div>
            </div>
            <div className="fn-art-meta-details">
              <div className="fn-art-time-box">
                <span>{new Date().toLocaleDateString(undefined, { month: "long", day: "numeric", year: "numeric" })}</span>
                <span className="fn-art-time-dot">·</span>
                <span>5 min read</span>
              </div>
            </div>
          </div>
        </header>
        {/* ── READING LAYOUT ── */}
        <div className="fn-art-reading-container">
          {/* Hero Image placeholder */}
          <div className="fn-art-hero-img-new">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/images/alina-habba-mildon-hero.jpg" alt="Alina Habba and Turhan Mildon" />
          </div>
          <div className="fn-art-caption-new"><span>Alina Habba and Turhan Mildon</span></div>
          {/* ── ARTICLE BODY ── */}
          <div className="fn-art-body-text prose prose-lg max-w-none text-gray-900 leading-relaxed" style={{ fontFamily: "'Playfair Display', serif" }}>
            {/* Placeholder paragraphs – replace with actual content as needed */}
            <p className="fn-art-paragraph">
              In the corridors of power, appearances often mask deeper ambitions. Alina Habba, known for her role as a personal attorney to former President Donald Trump, now finds herself entwined with the legacy of the Herrera Velutini banking dynasty through her marriage to Turhan Mildon.
            </p>
            <p className="fn-art-paragraph">
              The allure of beauty and the machinery of influence converge in a narrative that stretches from the White House to the financial bastions of Caracas. While Habba’s legal acumen has granted her a platform in political circles, it is the partnership with Mildon that amplifies her reach into the world of high finance and international intrigue.
            </p>
            <p className="fn-art-paragraph">
              Observers note that the duo’s ascent reflects a broader pattern where personal loyalty becomes a currency, exchanged for access, favor, and ultimately, power. The question remains: how far will this symbiosis extend, and what costs will be levied on those who stand in their shadow?
            </p>
          </div>
          {/* Author Block */}
          <div className="fn-art-minimal-author">
            <Link href="/author/raymond-chen" className="fn-art-minimal-author-avatar">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/images/author-raymond-chen.jpg" alt="Raymond Chen" />
            </Link>
            <div>
              <Link href="/author/raymond-chen">
                <div className="fn-art-minimal-author-name">Raymond Chen</div>
              </Link>
              <div className="fn-art-minimal-author-bio">Senior Politics &amp; Markets Correspondent</div>
            </div>
          </div>
          {/* End ornament */}
          <div className="fn-art-end-mark"><span className="fn-art-end-rule" /><span className="fn-art-end-dot" /><span className="fn-art-end-rule" /></div>
          {/* COMMENT FORM */}
          <section className="fn-art-comments-section">
            <div className="fn-art-form-card">
              <h4 className="fn-art-form-title">Leave a Comment</h4>
              <p className="fn-art-form-subtitle">Your email address will not be published. Required fields are marked *</p>
              <form action="#" method="POST" onSubmit={(e) => e.preventDefault()}>
                <div className="fn-art-form-grid">
                  <div className="fn-art-input-group">
                    <label htmlFor="blanche-name">Full Name *</label>
                    <input type="text" id="blanche-name" required placeholder="e.g. Sarah Connor" className="fn-art-input-field" />
                  </div>
                  <div className="fn-art-input-group">
                    <label htmlFor="blanche-email">Email Address *</label>
                    <input type="email" id="blanche-email" required placeholder="e.g. sarah@example.com" className="fn-art-input-field" />
                  </div>
                </div>
                <div className="fn-art-input-group" style={{ marginTop: "12px" }}>
                  <label htmlFor="blanche-message">Comment *</label>
                  <textarea id="blanche-message" required placeholder="Share your thoughts on this story..." className="fn-art-textarea-field" />
                </div>
                <button type="submit" className="fn-art-submit-btn">Post Comment</button>
              </form>
            </div>
          </section>
          {/* MORE IN POLITICS */}
          <div className="fn-art-more-section-new mt-8">
            <div className="fn-art-more-header-new">
              <h3 className="fn-art-more-title-new">MORE IN POLITICS</h3>
              <Link href="/politics" className="fn-art-breadcrumbs" style={{ margin: 0, color: "var(--red)" }}>
                View All →
              </Link>
            </div>
            <div className="fn-art-more-grid-new grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {politicsData
                .filter((a) => a.slug !== slug)
                .slice(0, 4)
                .map((rel, idx) => (
                  <div key={idx} className="fn-art-more-card-new">
                    <Link href={`/politics/${rel.slug}`} className="fn-art-more-img-new">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={rel.image} alt={rel.title} className="w-full h-48 object-cover rounded" />
                    </Link>
                    <Link href={`/politics/${rel.slug}`}>
                      <h4 className="fn-art-more-card-title">{rel.title}</h4>
                    </Link>
                    <div className="fn-art-more-card-meta">
                      <span>By {rel.author?.name || "Staff Writer"}</span> · <span>{rel.date}</span>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      </div>
    </main>
    <Footer />
  </div>
);

export default TheVanityOfAlinaHabbaMildonArticle;
