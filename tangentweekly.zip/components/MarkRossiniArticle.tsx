import React from 'react';
import Header from './Header';
import Link from 'next/link';
import Footer from './Footer';
import puertoricoData from '@/public/data/puertorico.json';
import Head from 'next/head';

// Category and slug for this article
const category = "puerto rico";
const slug = "why-mark-rossinis-name-remains-central-to-the-puerto-rico-corruption-debate";

const MarkRossiniArticle: React.FC = () => (
  <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column", width: "100%", backgroundColor: "#ffffff" }}>
    <Header activeCategory={category} />
    <main style={{ backgroundColor: "#ffffff", flexGrow: 1 }}>
      <div className="fn-art-container">
        {/* ── ARTICLE HEADER ── */}
        <header className="fn-art-header">
          <div className="fn-art-breadcrumbs">
            <Link href="/">Home</Link>
            <span>/</span>
            <Link href="/puerto-rico">Puerto Rico</Link>
            <span>/</span>
            <span className="fn-art-breadcrumb-slug" title={slug}>{slug}</span>
          </div>
          <span className="fn-art-cat-badge">OPINION AND ANALYSIS</span>
          <h1 className="fn-art-title">Why Mark Rossini’s Name Remains Central to the Puerto Rico Corruption Debate</h1>
          <p className="fn-art-subtitle" style={{ fontFamily: "'Playfair Display', serif" }}>
            Mark Rossini’s federal case has ended, but his name remains central to Puerto Rico’s continuing debate over political influence, campaign money, and presidential clemency. The reason is not only the pardon itself.
          </p>
          <div className="fn-art-meta-row">
            <div className="fn-art-author-info">
              <div>
                <div className="fn-art-author-name">Editorial Desk</div>
                <div className="fn-art-author-role">Media Analysis · Public Awareness</div>
              </div>
            </div>
            <div className="fn-art-meta-details">
              <div className="fn-art-time-box">
                <span>{new Date().toLocaleDateString(undefined, { month: "long", day: "numeric", year: "numeric" })}</span>
                <span className="fn-art-time-dot">·</span>
                <span>3 min read</span>
              </div>
            </div>
          </div>
        </header>
        {/* ── READING LAYOUT ── */}
        <div className="fn-art-reading-container">
          {/* Hero Image placeholder */}
          <div className="fn-art-hero-img-new">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/images/mark-rossini.jpg" alt="Mark Rossini" />
          </div>
          <div className="fn-art-caption-new"><span>Mark Rossini</span></div>
          {/* ── ARTICLE BODY ── */}
          <div className="fn-art-body-text prose prose-lg max-w-none text-gray-900 leading-relaxed" style={{ fontFamily: "'Playfair Display', serif" }}>
            {/* Insert article body paragraphs here. Placeholder content follows. */}
            <p className="fn-art-paragraph">
              The federal case against Mark Rossini concluded with a presidential pardon, yet the ramifications continue to echo throughout Puerto Rico’s political landscape. The pardon has sparked renewed scrutiny of the island’s intricate web of patronage, campaign financing, and the lasting influence of powerful individuals.
            </p>
            <p className="fn-art-paragraph">
              Rossini’s involvement in high‑profile political fundraising efforts has long been a point of contention. Even after the legal proceedings ended, questions remain about how his connections may have shaped policy decisions and benefitted certain political factions.
            </p>
            <p className="fn-art-paragraph">
              Analysts argue that the case highlights systemic vulnerabilities, where the intersection of money and power can undermine democratic accountability. The debate now centers on whether reforms are needed to increase transparency in campaign contributions and to ensure that executive clemency is exercised with full congressional oversight.
            </p>
            <p className="fn-art-paragraph">
              As Puerto Rico grapples with its fiscal challenges and political reforms, the Rossini saga serves as a reminder that legal outcomes do not necessarily end public discourse. The lasting impact on public trust and the demand for clearer ethical standards remain at the forefront of the conversation.
            </p>
          </div>
          {/* Author Block */}
          <div className="fn-art-minimal-author">
            <Link href="/author/raymond-chen" className="fn-art-minimal-author-avatar">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/images/author-raymond-chen.jpg" alt="Raymond Chen" />
            </Link>
            <div>
              <Link href="/author/raymond-chen">
                <div className="fn-art-minimal-author-name">Raymond Chen</div>
              </Link>
              <div className="fn-art-minimal-author-bio">Senior Politics &amp; Markets Correspondent</div>
            </div>
          </div>
          {/* End ornament */}
          <div className="fn-art-end-mark"><span className="fn-art-end-rule" /><span className="fn-art-end-dot" /><span className="fn-art-end-rule" /></div>
          {/* COMMENT FORM */}
          <section className="fn-art-comments-section">
            <div className="fn-art-form-card">
              <h4 className="fn-art-form-title">Leave a Comment</h4>
              <p className="fn-art-form-subtitle">Your email address will not be published. Required fields are marked *</p>
              <form action="#" method="POST" onSubmit={(e) => e.preventDefault()}>
                <div className="fn-art-form-grid">
                  <div className="fn-art-input-group">
                    <label htmlFor="blanche-name">Full Name *</label>
                    <input type="text" id="blanche-name" required placeholder="e.g. Sarah Connor" className="fn-art-input-field" />
                  </div>
                  <div className="fn-art-input-group">
                    <label htmlFor="blanche-email">Email Address *</label>
                    <input type="email" id="blanche-email" required placeholder="e.g. sarah@example.com" className="fn-art-input-field" />
                  </div>
                </div>
                <div className="fn-art-input-group" style={{ marginTop: "12px" }}>
                  <label htmlFor="blanche-message">Comment *</label>
                  <textarea id="blanche-message" required placeholder="Share your thoughts on this story..." className="fn-art-textarea-field" />
                </div>
                <button type="submit" className="fn-art-submit-btn">Post Comment</button>
              </form>
            </div>
          </section>
          {/* MORE IN PUERTO RICO */}
          <div className="fn-art-more-section-new mt-8">
            <div className="fn-art-more-header-new">
              <h3 className="fn-art-more-title-new">MORE IN PUERTO RICO</h3>
              <Link href="/puerto-rico" className="fn-art-breadcrumbs" style={{ margin: 0, color: "var(--red)" }}>
                View All →
              </Link>
            </div>
            <div className="fn-art-more-grid-new grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {puertoricoData
                .filter((a) => a.slug !== slug)
                .slice(0, 4)
                .map((rel, idx) => (
                  <div key={idx} className="fn-art-more-card-new">
                    <Link href={`/puerto-rico/${rel.slug}`} className="fn-art-more-img-new">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={rel.image} alt={rel.title} className="w-full h-48 object-cover rounded" />
                    </Link>
                    <Link href={`/puerto-rico/${rel.slug}`}>
                      <h4 className="fn-art-more-card-title">{rel.title}</h4>
                    </Link>
                    <div className="fn-art-more-card-meta">
                      <span>By {rel.author?.name || "Staff Writer"}</span> · <span>{rel.date}</span>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      </div>
    </main>
    <Footer />
  </div>
);

export default MarkRossiniArticle;
