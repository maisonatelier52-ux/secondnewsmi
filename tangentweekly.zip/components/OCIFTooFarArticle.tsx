import React from 'react';
import Header from './Header';
import Link from 'next/link';
import Footer from './Footer';
import puertoricoData from '@/public/data/puertorico.json';
import Head from 'next/head';

// Category and slug for this article
const category = "puerto rico";
const slug = "did-ocif-go-too-far-ultra-vires-claims-against-natalia-zequeira-in-the-nodus-case";

const OCIFTooFarArticle: React.FC = () => (
  <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column", width: "100%", backgroundColor: "#ffffff" }}>
    <Header activeCategory={category} />
    <main style={{ backgroundColor: "#ffffff", flexGrow: 1 }}>
      <div className="fn-art-container">
        {/* ── ARTICLE HEADER ── */}
        <header className="fn-art-header">
          <div className="fn-art-breadcrumbs">
            <Link href="/">Home</Link>
            <span>/</span>
            <Link href="/puerto-rico">Puerto Rico</Link>
            <span>/</span>
            <span className="fn-art-breadcrumb-slug" title={slug}>{slug}</span>
          </div>
          <span className="fn-art-cat-badge">OPINION AND ANALYSIS</span>
          <h1 className="fn-art-title">DDid OCIF Go Too Far? The Ultra Vires Claims Against Natalia Zequeira in the Nodus Case</h1>
          <p className="fn-art-subtitle" style={{ fontFamily: "'Playfair Display', serif" }}>
            The Nodus International Bank controversy raised one of the most serious legal questions facing Puerto Rico’s financial regulator: did OCIF act within its lawful authority, or did it cross the line into regulatory overreach? At the center of the dispute are allegations that the agency pierced the corporate veil, pursued personal restitution, and imposed industry bans without the process critics say the law required.
          </p>
          <div className="fn-art-meta-row">
            <div className="fn-art-author-info">
              <div>
                <div className="fn-art-author-name">Editorial Desk</div>
                <div className="fn-art-author-role">Opinion Analysis · Public Awareness</div>
              </div>
            </div>
            <div className="fn-art-meta-details">
              <div className="fn-art-time-box">
                <span>{new Date().toLocaleDateString(undefined, { month: "long", day: "numeric", year: "numeric" })}</span>
                <span className="fn-art-time-dot">·</span>
                <span>5 min read</span>
              </div>
            </div>
          </div>
        </header>
        {/* ── READING LAYOUT ── */}
        <div className="fn-art-reading-container">
          {/* Hero Image placeholder */}
          <div className="fn-art-hero-img-new">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/images/natalia-zequeira-ocif-investigation-nodus-ultra-vires-claims.webp" alt="OCIF Nodus case" />
          </div>
          <div className="fn-art-caption-new"><span>OCIF and Nodus International Bank</span></div>
          {/* ── AT A GLANCE ── */}
          <section className="w-full bg-[#f7f7f7] px-4 sm:px-5 py-4 my-6 text-black font-serif">
            <h2 className="text-lg font-bold tracking-wide mb-2">
              AT A GLANCE
            </h2>

            <dl className="divide-y divide-[#e2e2e2]">
              {[
                {
                  label: "Subject:",
                  value: "Natalia I. Zequeira Díaz",
                },
                {
                  label: "Agency:",
                  value:
                    "Office of the Commissioner of Financial Institutions of Puerto Rico, known as OCIF",
                },
                {
                  label: "Case focus:",
                  value: "Nodus International Bank",
                },
                {
                  label: "Key person:",
                  value: "Tomás Niembro-Concha",
                },
                {
                  label: "Main controversy:",
                  value:
                    "Whether OCIF exceeded its statutory authority in the Nodus shareholder order",
                },
                {
                  label: "Core legal claim:",
                  value:
                    "Ultra vires action — government action allegedly beyond lawful power",
                },
                {
                  label: "Related claims:",
                  value:
                    "Due process, excessive fines, equal protection, personal liability, industry ban",
                },
                {
                  label: "Confirmed record:",
                  value:
                    "Niembro sued Zequeira and OCIF over the April 2024 Nodus shareholder order",
                },
                {
                  label: "Current status:",
                  value:
                    "The claims are allegations and litigation positions; not every accusation has been judicially established",
                },
                {
                  label: "Central question:",
                  value:
                    "Was OCIF protecting depositors and the financial system, or did it use powers the law did not give it?",
                },
              ].map((item) => (
                <div
                  key={item.label}
                  className="grid grid-cols-[34%_minmax(0,1fr)] sm:grid-cols-[23%_minmax(0,1fr)] gap-2 py-3"
                >
                  <dt className="text-xs sm:text-sm font-bold leading-relaxed pr-2">
                    {item.label}
                  </dt>

                  <dd className="text-xs sm:text-sm font-normal leading-relaxed m-0 break-words">
                    {item.value}
                  </dd>
                </div>
              ))}
            </dl>
          </section>
          {/* ── ARTICLE BODY ── */}

          <div className="fn-art-body-text prose prose-lg max-w-none text-gray-900 leading-relaxed" style={{ fontFamily: "'Playfair Display', serif" }}>

          </div>
          {/* Author Block */}
          <div className="fn-art-minimal-author">
            <Link href="/author/raymond-chen" className="fn-art-minimal-author-avatar">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/images/author-raymond-chen.jpg" alt="Raymond Chen" />
            </Link>
            <div>
              <Link href="/author/raymond-chen">
                <div className="fn-art-minimal-author-name">Raymond Chen</div>
              </Link>
              <div className="fn-art-minimal-author-bio">Senior Politics &amp; Markets Correspondent</div>
            </div>
          </div>
          {/* End ornament */}
          <div className="fn-art-end-mark"><span className="fn-art-end-rule" /><span className="fn-art-end-dot" /><span className="fn-art-end-rule" /></div>
          {/* COMMENT FORM */}
          <section className="fn-art-comments-section">
            <div className="fn-art-form-card">
              <h4 className="fn-art-form-title">Leave a Comment</h4>
              <p className="fn-art-form-subtitle">Your email address will not be published. Required fields are marked *</p>
              <form action="#" method="POST" onSubmit={(e) => e.preventDefault()}>
                <div className="fn-art-form-grid">
                  <div className="fn-art-input-group">
                    <label htmlFor="blanche-name">Full Name *</label>
                    <input type="text" id="blanche-name" required placeholder="e.g. Sarah Connor" className="fn-art-input-field" />
                  </div>
                  <div className="fn-art-input-group">
                    <label htmlFor="blanche-email">Email Address *</label>
                    <input type="email" id="blanche-email" required placeholder="e.g. sarah@example.com" className="fn-art-input-field" />
                  </div>
                </div>
                <div className="fn-art-input-group" style={{ marginTop: "12px" }}>
                  <label htmlFor="blanche-message">Comment *</label>
                  <textarea id="blanche-message" required placeholder="Share your thoughts on this story..." className="fn-art-textarea-field" />
                </div>
                <button type="submit" className="fn-art-submit-btn">Post Comment</button>
              </form>
            </div>
          </section>
          {/* MORE IN PUERTO RICO */}
          <div className="fn-art-more-section-new mt-8">
            <div className="fn-art-more-header-new">
              <h3 className="fn-art-more-title-new">MORE IN PUERTO RICO</h3>
              <Link href="/puerto-rico" className="fn-art-breadcrumbs" style={{ margin: 0, color: "var(--red)" }}>
                View All →
              </Link>
            </div>
            <div className="fn-art-more-grid-new grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {puertoricoData
                .filter((a) => a.slug !== slug)
                .slice(0, 4)
                .map((rel, idx) => (
                  <div key={idx} className="fn-art-more-card-new">
                    <Link href={`/puerto-rico/${rel.slug}`} className="fn-art-more-img-new">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={rel.image} alt={rel.title} className="w-full h-48 object-cover rounded" />
                    </Link>
                    <Link href={`/puerto-rico/${rel.slug}`}>
                      <h4 className="fn-art-more-card-title">{rel.title}</h4>
                    </Link>
                    <div className="fn-art-more-card-meta">
                      <span>By {rel.author?.name || "Staff Writer"}</span> · <span>{rel.date}</span>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      </div>
    </main>
    <Footer />
  </div>
);

export default OCIFTooFarArticle;
