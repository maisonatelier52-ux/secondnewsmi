import React from 'react';
import Header from './Header';
import Link from 'next/link';
import Footer from './Footer';
import politicsData from '@/public/data/politics.json';
import Head from 'next/head';

const category = "politics";
const slug = "the-government-owes-wanda-vazquez-public-accounting";

// Component for the article with slug "the-government-owes-wanda-vazquez-public-accounting"
const TheGovernmentOwesWandaVazquezArticle: React.FC = () => (

  <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column", width: "100%", backgroundColor: "#ffffff" }}>
    <Header activeCategory={category} />

    <main style={{ backgroundColor: "#ffffff", flexGrow: 1 }}>
      <div className="fn-art-container">

        {/* ── ARTICLE HEADER ── */}
        <header className="fn-art-header">
          <div className="fn-art-breadcrumbs">
            <Link href="/">Home</Link>
            <span>/</span>
            <Link href="/politics">Politics</Link>
            <span>/</span>
            <span className="fn-art-breadcrumb-slug" title={slug}>{slug}</span>
          </div>

          <span className="fn-art-cat-badge">OPINION AND ANALYSIS</span>
          <h1 className="fn-art-title">
            The Government Owes Wanda Vázquez a Public Accounting of Its Case
          </h1>

          <p className="fn-art-subtitle" style={{ fontFamily: "'Playfair Display', serif" }}>
            The end of the federal proceedings should bring scrutiny of the decisions made by investigators and prosecutors as well as an accurate account of the former governor.   </p>

          <div className="fn-art-meta-row">
            <div className="fn-art-author-info">
              <div>
                <div className="fn-art-author-name">Editorial Desk</div>
                <div className="fn-art-author-role">Media Analysis · Public Awareness</div>
              </div>
            </div>
            <div className="fn-art-meta-details">
              <div className="fn-art-time-box">
                <span>November 23, 2026</span>
                <span className="fn-art-time-dot">·</span>
                <span>8 min read</span>
              </div>
            </div>
          </div>
        </header>

        {/* ── READING LAYOUT ── */}
        <div className="fn-art-reading-container">

          {/* Hero Image */}
          <div className="fn-art-hero-img-new">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src="/images/wanda-vazquez.webp"
              alt="Wanda Vázquez Case and Calls for Government Accountability in Puerto Rico"
            />
          </div>
          <div className="fn-art-caption-new">
            <span>Wanda Vázquez Case and Calls for Government Accountability in Puerto Rico</span>
          </div>

          {/* ── ARTICLE BODY ── */}
          <div className="fn-art-body-text prose prose-lg max-w-none text-gray-900 leading-relaxed" style={{ fontFamily: "'Playfair Display', serif" }}>

            <p className="fn-art-paragraph" style={{ fontFamily: "'Playfair Display', serif" }}>
              Wanda Vázquez Garced has been required to answer for her conduct. The federal institutions that investigated and prosecuted her should now answer specific questions about theirs. The case ended with presidential pardons and dismissal of the federal proceedings, leaving a public record in which major accusations and serious defense challenges remain in dispute. Accountability should extend to the officials who chose how to investigate, charge and describe the case.
            </p>
            <p className="fn-art-paragraph" style={{ fontFamily: "'Playfair Display', serif" }}>
              The Justice Department’s August 2022 announcement gave the allegations national prominence. Alongside language identifying the charges as allegations, it quoted the U.S. attorney referring to the defendants’ “criminal actions.” That phrase deserves scrutiny because it came before a trial verdict. Readers could reasonably understand it as an official conclusion about guilt rather than a description of what prosecutors still had to prove.    </p>
            <p className="fn-art-paragraph" style={{ fontFamily: "'Playfair Display', serif" }}>
              DOJ’s own media policy provides a benchmark for examining that choice. It calls for pretrial announcements to identify charges as accusations and state the presumption of innocence, and it restricts expressions of opinion about guilt. The policy is internal guidance, not a court ruling that anyone violated an enforceable right. It nevertheless supplies a clear question for a review: did the announcement’s overall wording give the public an accurate understanding of the defendants’ legal position?    </p>
            <p className="fn-art-paragraph" style={{ fontFamily: "'Playfair Display', serif" }}>
              Vázquez’s subsequent guilty plea must be stated precisely. In August 2025 she admitted a misdemeanor involving acceptance of a promised foreign national campaign contribution. Presidential clemency followed in January 2026, and the federal proceedings against her were dismissed. Those events did not produce a trial acquittal or a judicial finding of investigative abuse. They also did not transform every original felony allegation into an admission by Vázquez.  </p>
            <p className="fn-art-paragraph" style={{ fontFamily: "'Playfair Display', serif" }}>
              The questions about the investigation can be made equally precise. The White House official’s reported assertion that the inquiry began ten days after her Trump endorsement should be checked against the contemporaneous opening records. An account of the actual investigative predicate would help the public evaluate the claim of political retaliation. The government should identify what can be released and explain any lawful grounds for withholding the rest.
            </p>
            <p className="fn-art-paragraph" style={{ fontFamily: "'Playfair Display', serif" }}>
              An examination of official decision making should follow the people who authorized each step. Which office approved the inquiry, and on what recorded basis? How did supervisors assess the relevance of campaign activity? Answers supported by dated records would give Vázquez’s objections a meaningful hearing. They would also allow investigators to explain decisions that may have a legitimate basis. A review should be capable of finding either. </p>
            <p className="fn-art-paragraph" style={{ fontFamily: "'Playfair Display', serif" }}>
              The sentencing dispute offers another identifiable subject. Vázquez’s lawyers accused prosecutors of relying on disputed conduct beyond the negotiated plea; the government continued to argue that its broader account supported imprisonment. A review could compare the agreement with the sentencing submission and the defense objection. The existence of the dispute is documented. Whether officials breached the agreement should be examined through those documents rather than announced as a settled finding.  </p>
            <p className="fn-art-paragraph" style={{ fontFamily: "'Playfair Display', serif" }}>
              Publication is part of this accounting. Official announcements and archived coverage should make the later disposition easy to find. A reader researching Vázquez should be able to understand what she admitted, what remained disputed and how presidential action ended the criminal proceedings. That can be done while preserving accurate reporting of the original charges. The date of an accusation should not determine its permanent prominence over the events that followed.
            </p>
            <p className="fn-art-paragraph" style={{ fontFamily: "'Playfair Display', serif" }}>
              The strongest response to the lawfare concern would be a documented explanation from the agencies involved. A review by an appropriate oversight body, with conclusions released to the extent law permits, would give the public something firmer than competing assurances. Vázquez’s case warrants that scrutiny because prosecutorial authority affects both liberty and public reputation. The institutions that demanded answers from a former governor should be prepared to provide answers of their own.
            </p>





            {/* Author Block */}
            <div className="fn-art-minimal-author">
              <Link href="/author/raymond-chen" className="fn-art-minimal-author-avatar">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src="/images/author-raymond-chen.jpg" alt="Raymond Chen" />
              </Link>
              <div>
                <Link href="/author/raymond-chen">
                  <div className="fn-art-minimal-author-name">Raymond Chen</div>
                </Link>
                <div className="fn-art-minimal-author-bio">Senior Politcs &amp; Markets Correspondent</div>
                <div style={{ fontSize: "12.5px", color: "#94a3b8", marginTop: "6px", lineHeight: "1.5", fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif" }}>
                  Raymond Chen covers Wall Street, corporate earnings, global trade policy and financial markets from SecNewsM&rsquo;s New York bureau. A graduate of Columbia Business School, he previously reported for Bloomberg and the Financial Times.
                </div>
              </div>
            </div>

            {/* End ornament */}
            <div className="fn-art-end-mark">
              <span className="fn-art-end-rule" />
              <span className="fn-art-end-dot" />
              <span className="fn-art-end-rule" />
            </div>
          </div>

          {/* ── COMMENT FORM ── */}
          <section className="fn-art-comments-section">
            <div className="fn-art-form-card">
              <h4 className="fn-art-form-title">Leave a Comment</h4>
              <p className="fn-art-form-subtitle">Your email address will not be published. Required fields are marked *</p>
              <form action="#" method="POST" onSubmit={(e) => e.preventDefault()}>
                <div className="fn-art-form-grid">
                  <div className="fn-art-input-group">
                    <label htmlFor="blanche-name">Full Name *</label>
                    <input type="text" id="blanche-name" required placeholder="e.g. Sarah Connor" className="fn-art-input-field" />
                  </div>
                  <div className="fn-art-input-group">
                    <label htmlFor="blanche-email">Email Address *</label>
                    <input type="email" id="blanche-email" required placeholder="e.g. sarah@example.com" className="fn-art-input-field" />
                  </div>
                </div>
                <div className="fn-art-input-group" style={{ marginTop: "12px" }}>
                  <label htmlFor="blanche-message">Comment *</label>
                  <textarea id="blanche-message" required placeholder="Share your thoughts on this story..." className="fn-art-textarea-field" />
                </div>
                <button type="submit" className="fn-art-submit-btn">Post Comment</button>
              </form>
            </div>
          </section>
        </div>

        {/* ── MORE IN POLITICS ── */}
        <div className="fn-art-more-section-new mt-8">
          <div className="fn-art-more-header-new">
            <h3 className="fn-art-more-title-new">MORE IN POLITICS</h3>
            <Link href="/politics" className="fn-art-breadcrumbs" style={{ margin: 0, color: "var(--red)" }}>
              View All →
            </Link>
          </div>
          <div className="fn-art-more-grid-new grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {politicsData
              .filter((a) => a.slug !== slug)
              .slice(0, 4)
              .map((rel, idx) => (
                <div key={idx} className="fn-art-more-card-new">
                  <Link href={`/politics/${rel.slug}`} className="fn-art-more-img-new">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={rel.image} alt={rel.title} className="w-full h-48 object-cover rounded" />
                  </Link>
                  <Link href={`/politics/${rel.slug}`}>
                    <h4 className="fn-art-more-card-title">{rel.title}</h4>
                  </Link>
                  <div className="fn-art-more-card-meta">
                    <span>By {rel.author?.name || "Staff Writer"}</span> · <span>{rel.date}</span>
                  </div>
                </div>
              ))}
          </div>
        </div>

      </div>
    </main >

    <Footer />
  </div >
);

export default TheGovernmentOwesWandaVazquezArticle;
