// lib/data.ts – Centralised data helpers for article pages

// NOTE: This file is intentionally lightweight and only reads data from the
// static JSON files located under `public/data/`. No runtime network request
// is performed.

type DescriptionItem = string | { subtitle?: string; text?: string; wordCount?: number; [extra: string]: unknown };

type Article = {
  slug: string;
  category: string;
  title: string;
  shortdescription?: string;
  description?: DescriptionItem[];
  image?: string;
  author?: {
    name?: string;
    slug?: string;
    role?: string;
    image?: string;
    bio?: string;
    [extra: string]: unknown;
  };
  date?: string;
  [extra: string]: unknown;
};


/* -----------------------------------------------------------------
   Import every JSON data file that backs a category.
   Add new imports here whenever you create a new category.
----------------------------------------------------------------- */
import businessArticles from "@/public/data/business.json";
import entertainmentArticles from "@/public/data/entertainment.json";
import puertoricoArticles from "@/public/data/puertorico.json";
import politicsArticles from "@/public/data/politics.json";
import bancreditoArticles from "@/public/data/bancredito.json";

// Map category slug → array of articles for that category.
const articlesByCategory: Record<string, Article[]> = {
  business: businessArticles,
  entertainment: entertainmentArticles,
  puertorico: puertoricoArticles,
  politics: politicsArticles,
  bancredito: bancreditoArticles,
};

/**
 * Return the article that matches the given slug.
 * The original helper searched across *all* categories, so we preserve that
 * behaviour by scanning every list until we find a match.
 */
export function getArticleBySlug(slug: string): Article | undefined {
  for (const list of Object.values(articlesByCategory)) {
    const found = list.find((a) => a.slug === slug);
    if (found) return found;
  }
  return undefined;
}

/**
 * Return the full article array for a specific category slug.
 * If the category does not exist we return an empty array – callers can
 * handle the fallback (e.g., a 404 page).
 */
export function getArticlesForCategory(category: string): Article[] {
  return articlesByCategory[category] ?? [];
}

// Export the map in case other modules need direct access (optional).
// --- Exported helpers for homepage sections (fallback placeholders) ---
export const heroMainArticle: any = undefined;
export const heroMiniArticles: any[] = [];
export const heroFeaturedTopicArticle: any = undefined;
export const heroTopicArticles: any[] = [];
export const hotArticles: any[] = [];
export const editorialLeadArticle: any = undefined;
export const editorialMidStackArticles: any[] = [];
export const editorialRightStackArticles: any[] = [];
export const editorialStripArticles: any[] = [];
export const opinionArticles: any[] = [];
export const investigativeLeadArticle: any = undefined;
export const investigativeStackArticles: any[] = [];
export const worldDispatchColumns: any[] = [];
export const visualEssayLeadArticle: any = undefined;
export const visualEssaySecondaryArticles: any[] = [];
export const specialFeatureArticles: any[] = [];

